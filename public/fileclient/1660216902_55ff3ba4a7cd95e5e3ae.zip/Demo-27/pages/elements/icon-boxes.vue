<template>
    <main class="main">
        <page-header title="Icon Boxes" subtitle="Elements"></page-header>

        <nav class="breadcrumb-nav">
            <div class="container">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <nuxt-link to="/">Home</nuxt-link>
                    </li>
                    <li class="breadcrumb-item">
                        <nuxt-link to="/elements">Elements</nuxt-link>
                    </li>
                    <li class="breadcrumb-item active">Icon Boxes</li>
                </ol>
            </div>
        </nav>

        <div class="page-content">
            <div class="container">
                <h2 class="title mb-4 text-center">
                    Simple Icons
                    <span class="title-separator">/</span> Centered Align
                    <span class="title-separator">/</span> 3 Columns
                </h2>

                <div class="row justify-content-center">
                    <div class="col-lg-4 col-sm-6">
                        <div class="icon-box text-center">
                            <span class="icon-box-icon">
                                <i class="icon-info-circle"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Quisque a lectus</h3>

                                <p>Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-sm-6">
                        <div class="icon-box text-center">
                            <span class="icon-box-icon">
                                <i class="icon-star-o"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Suspendisse potenti</h3>

                                <p>Praesent dapibus, neque id cursus faucibus, tortor neque egestas augue, eu vulputate magna eros eu erat.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-sm-6">
                        <div class="icon-box text-center">
                            <span class="icon-box-icon">
                                <i class="icon-heart-o"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Phasellus hendrerit</h3>

                                <p>Pellentesque a diam sit amet mi ullamcorper vehicula. Nullam quis massa sit amet nibh viverra malesuada.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <hr class="mb-6" />

                <h2 class="title mb-5 text-center">
                    Simple Icons
                    <span class="title-separator">/</span> Left Align
                    <span class="title-separator">/</span> 3 Columns
                </h2>

                <div class="row justify-content-center">
                    <div class="col-lg-4 col-sm-6">
                        <div class="icon-box icon-box-left">
                            <span class="icon-box-icon">
                                <i class="icon-info-circle"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Quisque a lectus</h3>

                                <p>Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-sm-6">
                        <div class="icon-box icon-box-left">
                            <span class="icon-box-icon">
                                <i class="icon-star-o"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Suspendisse potenti</h3>

                                <p>Praesent dapibus, neque id cursus faucibus, tortor neque egestas augue, eu vulputate magna eros eu erat.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-sm-6">
                        <div class="icon-box icon-box-left">
                            <span class="icon-box-icon">
                                <i class="icon-heart-o"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Phasellus hendrerit</h3>

                                <p>Pellentesque a diam sit amet vehicula. Nullam quis massa sit amet nibh viverra malesuada.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <hr class="mb-6" />

                <h2 class="title mb-4 text-center">
                    Circle Icons
                    <span class="title-separator">/</span> Centered Align
                    <span class="title-separator">/</span> 3 Columns
                </h2>

                <div class="row justify-content-center">
                    <div class="col-lg-4 col-sm-6">
                        <div class="icon-box icon-box-circle text-center">
                            <span class="icon-box-icon">
                                <i class="icon-info-circle"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Quisque a lectus</h3>

                                <p>Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-sm-6">
                        <div class="icon-box icon-box-circle text-center">
                            <span class="icon-box-icon">
                                <i class="icon-star-o"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Suspendisse potenti</h3>

                                <p>Praesent dapibus, neque id cursus faucibus, tortor neque egestas augue, eu vulputate magna eros eu erat.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-sm-6">
                        <div class="icon-box icon-box-circle text-center">
                            <span class="icon-box-icon">
                                <i class="icon-heart-o"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Phasellus hendrerit</h3>

                                <p>Pellentesque a diam sit amet mi ullamcorper vehicula. Nullam quis massa sit amet nibh viverra malesuada.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <hr class="mb-6" />

                <h2 class="title mb-5 text-center">
                    Circle Icons
                    <span class="title-separator">/</span> Left Align
                    <span class="title-separator">/</span> 3 Columns
                </h2>

                <div class="row justify-content-center">
                    <div class="col-lg-4 col-sm-6">
                        <div class="icon-box icon-box-left icon-box-circle">
                            <span class="icon-box-icon">
                                <i class="icon-info-circle"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Quisque a lectus</h3>

                                <p>Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus augue.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-sm-6">
                        <div class="icon-box icon-box-left icon-box-circle">
                            <span class="icon-box-icon">
                                <i class="icon-star-o"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Suspendisse potenti</h3>

                                <p>Praesent dapibus, neque id cursus faucibus, tortor neque egestas augue, eu vulputate eu erat.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-sm-6">
                        <div class="icon-box icon-box-left icon-box-circle">
                            <span class="icon-box-icon">
                                <i class="icon-heart-o"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Phasellus hendrerit</h3>

                                <p>Pellentesque a diam sit amet vehicula. Nullam quis massa sit amet nibh viverra malesuada.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <hr class="mb-6" />

                <h2 class="title mb-4 text-center">
                    Simple Icons
                    <span class="title-separator">/</span> Centered Align
                    <span class="title-separator">/</span> 4 Columns
                </h2>

                <div class="row justify-content-center">
                    <div class="col-lg-3 col-sm-6">
                        <div class="icon-box text-center">
                            <span class="icon-box-icon">
                                <i class="icon-info-circle"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Quisque a lectus</h3>

                                <p>Sed egestas, ante et vulputate volutpat, eros pede semper</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-sm-6">
                        <div class="icon-box text-center">
                            <span class="icon-box-icon">
                                <i class="icon-star-o"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Suspendisse potenti</h3>

                                <p>Praesent dapibus, neque id cursus faucibus, tortor neque egestas</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-sm-6">
                        <div class="icon-box text-center">
                            <span class="icon-box-icon">
                                <i class="icon-heart-o"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Phasellus hendrerit</h3>

                                <p>Pellentesque a diam sit amet mi ullamcorper vehicula.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-sm-6">
                        <div class="icon-box text-center">
                            <span class="icon-box-icon">
                                <i class="icon-cog"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Fusce pellentesque</h3>

                                <p>Nullam quis massa sit amet nibh viverra malesuada.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <hr class="mb-6" />

                <h2 class="title mb-5 text-center">
                    Simple Icons
                    <span class="title-separator">/</span> Left Align
                    <span class="title-separator">/</span> 4 Columns
                </h2>

                <div class="row justify-content-center">
                    <div class="col-lg-3 col-sm-6">
                        <div class="icon-box icon-box-left">
                            <span class="icon-box-icon">
                                <i class="icon-info-circle"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Quisque a lectus</h3>

                                <p>Sed egestas, ante et vulputate volutpat eros</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-sm-6">
                        <div class="icon-box icon-box-left">
                            <span class="icon-box-icon">
                                <i class="icon-star-o"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Suspendisse potenti</h3>

                                <p>Praesent dapibus, neque id cursus faucibus tortor</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-sm-6">
                        <div class="icon-box icon-box-left">
                            <span class="icon-box-icon">
                                <i class="icon-heart-o"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Phasellus hendrerit</h3>

                                <p>Pellentesque a diam sit amet vehicula.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-sm-6">
                        <div class="icon-box icon-box-left">
                            <span class="icon-box-icon">
                                <i class="icon-cog"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Fusce pellentesque</h3>

                                <p>Nullam quis massa sit amet nibh viverra</p>
                            </div>
                        </div>
                    </div>
                </div>

                <hr class="mb-6" />

                <h2 class="title mb-4 text-center">
                    Circle Icons
                    <span class="title-separator">/</span> Centered Align
                    <span class="title-separator">/</span> 4 Columns
                </h2>

                <div class="row justify-content-center">
                    <div class="col-lg-3 col-sm-6">
                        <div class="icon-box icon-box-circle text-center">
                            <span class="icon-box-icon">
                                <i class="icon-info-circle"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Quisque a lectus</h3>

                                <p>Sed egestas, ante et vulputate volutpat, eros pede semper</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-sm-6">
                        <div class="icon-box icon-box-circle text-center">
                            <span class="icon-box-icon">
                                <i class="icon-star-o"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Suspendisse potenti</h3>

                                <p>Praesent dapibus, neque id cursus faucibus, tortor neque egestas</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-sm-6">
                        <div class="icon-box icon-box-circle text-center">
                            <span class="icon-box-icon">
                                <i class="icon-heart-o"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Phasellus hendrerit</h3>

                                <p>Pellentesque a diam sit amet mi ullamcorper vehicula.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-sm-6">
                        <div class="icon-box icon-box-circle text-center">
                            <span class="icon-box-icon">
                                <i class="icon-cog"></i>
                            </span>
                            <div class="icon-box-content">
                                <h3 class="icon-box-title">Fusce pellentesque</h3>

                                <p>Nullam quis massa sit amet nibh viverra malesuada.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <element-list></element-list>
    </main>
</template>

<script>
import PageHeader from '~/components/elements/PageHeader';
import ElementList from '~/components/partial/elements/ElementList';

export default {
    components: {
        PageHeader,
        ElementList
    }
};
</script>