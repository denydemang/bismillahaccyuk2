<template>
    <div class="main home-page">
        <div class="section-wrapper active">
            <div class="section section-scroll intro-section">
                <div
                    class="banner banner-big"
                    v-lazy:background-image="'./images/home/sliders/slide-1.jpg'"
                    style="background-color: #aeaeae;"
                >
                    <div class="banner-content">
                        <h5 class="banner-subtitle text-white">END OF SEASON SALE</h5>
                        <h3 class="banner-title text-white">Your Fall Fashion</h3>
                        <nuxt-link to="/shop/sidebar/list" class="btn btn-secondary">DISCOVER NOW</nuxt-link>
                    </div>
                </div>
            </div>
        </div>
        <div class="section-wrapper">
            <women-collection :products="womenProducts" v-if="loaded"></women-collection>
        </div>
        <div class="section-wrapper">
            <div class="section section-scroll video-section">
                <figure
                    class="banner video-banner banner-big"
                    v-lazy:background-image="'./images/home/banners/2.jpg'"
                    style="background-color: #84aea3"
                >
                    <div class="banner-content">
                        <h3 class="banner-title text-white">Bags & Accessories. New Season.</h3>
                        <a
                            href="https://www.youtube.com/watch?v=vBPgmASQ1A0"
                            class="btn-video btn-iframe"
                            @click.prevent="openVideoModal"
                        >
                            <i class="icon-play"></i>
                        </a>
                    </div>
                </figure>
            </div>
        </div>
        <div class="section-wrapper">
            <men-collection :products="menProducts" v-if="loaded"></men-collection>
        </div>
        <div class="section-wrapper">
            <new-collection :products="newProducts" v-if="loaded"></new-collection>
        </div>
        <button id="scroll-top" ref="scrollTop" title="Back to Top" @click.prevent="scrollTop">
            <i class="icon-arrow-up"></i>
        </button>
    </div>
</template>
<script>
import { mapGetters } from 'vuex';

import CountDown from '~/components/elements/CountDown';
import WomenCollection from '~/components/partial/home/WomenCollection';
import MenCollection from '~/components/partial/home/MenCollection';
import NewCollection from '~/components/partial/home/NewCollection';
import BlogSection from '~/components/partial/home/BlogSection';
import NewsletterModal from '~/components/elements/modals/NewsletterModal';

import Repository, { baseUrl } from '~/repositories/repository.js';
import {
    attrFilter,
    catFilter,
    isSafariBrowser,
    isEdgeBrowser
} from '~/utilities/common';
import {
    carouselSettingSingle,
    carouselSettingDefault
} from '~/utilities/carousel';
import { homeData } from '~/utilities/data';

export default {
    layout: 'layout1',
    components: {
        BlogSection,
        NewCollection,
        WomenCollection,
        MenCollection
    },
    data: function() {
        return {
            loaded: false,
            products: [],
            newProducts: [],
            womenProducts: [],
            menProducts: [],
            blogs: [],
            carouselSetting1: {
                ...carouselSettingSingle,
                pagination: {
                    el: '.swiper-1 .swiper-dots',
                    clickable: true
                }
            },
            carouselSetting2: {
                ...carouselSettingDefault,
                slidesPerView: 7,
                spaceBetween: 0,
                breakpoints: {
                    992: {
                        slidesPerView: 6
                    },
                    768: {
                        slidesPerView: 5
                    },
                    576: {
                        slidesPerView: 3
                    },
                    480: {
                        slidesPerView: 2
                    }
                }
            },
            options: {},
            homeData: homeData,
            flag: false,
            scrollableFlag: false,
            touchDirection: '',
            touchstartY: 0,
            touchendY: 0,
            checkTimer: null
        };
    },
    computed: {
        ...mapGetters('demo', ['newsletterShow'])
    },
    created: function() {
        this.getProducts();
    },
    mounted: function() {
        document.querySelector('header').classList.remove('position-relative');
        if (this.newsletterShow) {
            setTimeout(() => {
                if (this.$route.path == '/' && this.newsletterShow) {
                    this.$modal.show(
                        NewsletterModal,
                        {},
                        { width: '970', height: 'auto', adaptive: true }
                    );
                }
            }, 8000);
        }

        let scrollTop = this.$refs.scrollTop;
        document.addEventListener(
            'scroll',
            function() {
                if (window.pageYOffset >= 400) {
                    scrollTop.classList.add('show');
                } else {
                    scrollTop.classList.remove('show');
                }
            },
            false
        );
    },
    beforeDestroy: function() {
        document.querySelector('header').classList.add('position-relative');
        document.querySelector('body').classList.remove('overflow-hidden');
        document.querySelector('.section-scroll-nav').outerHTML = '';
        window.removeEventListener('resize', this.updateSectionHeight);

        let body = document.querySelector('body');
        let wheelEvent =
            'onwheel' in document
                ? 'wheel pointermove'
                : document.onmousewheel !== undefined
                ? 'mousewheel pointermove'
                : 'DOMMouseScroll pointermove';
        body.removeEventListener('pointerdown', this.pointerDownHandler);
        let self = this;
        wheelEvent.split(' ').forEach(function(eventName) {
            body.removeEventListener(eventName, self.scrollHandler);
        });
    },
    methods: {
        scrollTop: function() {
            document.querySelector('.section-scroll-nav a').click();
        },

        getProducts: async function() {
            this.loaded = false;
            await Repository.get(`${baseUrl}/demo27`)
                .then(response => {
                    this.products = response.data.products;
                    this.newProducts = attrFilter(this.products, 'new');
                    this.womenProducts = catFilter(this.products, ['women']);
                    this.menProducts = catFilter(this.products, ['men']);
                    this.blogs = response.data.blogs;
                    this.loaded = true;
                    this.$nextTick(() => {
                        this.buildScroll();
                        window.addEventListener(
                            'resize',
                            this.updateSectionHeight
                        );
                    });
                })
                .catch(error => ({ error: JSON.stringify(error) }));
        },

        buildScroll: function() {
            document.querySelector('body').classList.add('overflow-hidden');
            // document.querySelector('html').classList.add('overflow-hidden');
            let sections = document.querySelectorAll('.section-scroll');

            this.updateSectionHeight();

            setTimeout(() => {
                let sectionWrappers = document.querySelectorAll(
                    '.section-wrapper'
                );
                for (let i = 0; i < sectionWrappers.length; i++) {
                    sectionWrappers[i].style.height =
                        sectionWrappers[i]
                            .querySelector('.section-scroll')
                            .getBoundingClientRect().height + 'px';
                }
            }, 300);

            let body = document.querySelector('body');
            let wheelEvent =
                'onwheel' in document
                    ? 'wheel pointermove'
                    : document.onmousewheel !== undefined
                    ? 'mousewheel pointermove'
                    : 'DOMMouseScroll pointermove';
            body.addEventListener('pointerdown', this.pointerDownHandler);
            let self = this;
            wheelEvent.split(' ').forEach(function(eventName) {
                body.addEventListener(eventName, self.scrollHandler);
            });

            // Dots Navigation
            self.dotsNavigation();

            self.scrollTop();

            let sectionWrappers = document.querySelectorAll('.section-wrapper');
        },

        updateSectionHeight: function() {
            let sections = document.querySelectorAll('.section-scroll');
            for (let i = 0; i < sections.length; i++) {
                sections[i].style.height = '';
                if (
                    sections[i].getBoundingClientRect().height <
                    window.innerHeight + 3
                ) {
                    sections[i].classList.remove('section-scroll-scrollable');
                    sections[i].style.height = '100vh';
                } else {
                    sections[i].classList.add('section-scroll-scrollable');
                }
            }

            setTimeout(() => {
                let sectionWrappers = document.querySelectorAll(
                    '.section-wrapper'
                );
                for (let i = 0; i < sectionWrappers.length; i++) {
                    sectionWrappers[i].style.height =
                        sectionWrappers[i].children[0].getBoundingClientRect()
                            .height + 'px';
                }
            }, 100);
        },
        pointerDownHandler: function($event) {
            if (
                typeof $event.pointerType === 'undefined' ||
                'mouse' != $event.pointerType
            ) {
                this.touchstartY = this.getEventsPage($event).y;
            }
        },
        getEventsPage: function(e) {
            var events = [];

            events.y =
                typeof e.pageY !== 'undefined' && (e.pageY || e.pageX)
                    ? e.pageY
                    : e.touches[0].pageY;
            events.x =
                typeof e.pageX !== 'undefined' && (e.pageY || e.pageX)
                    ? e.pageX
                    : e.touches[0].pageX;

            if (
                ('ontouchstart' in window || navigator.msMaxTouchPoints) &&
                (typeof e.pointerType === 'undefined' ||
                    e.pointerType != 'mouse') &&
                typeof e.touches !== 'undefined'
            ) {
                events.y = e.touches[0].pageY;
                events.x = e.touches[0].pageX;
            }

            return events;
        },
        scrollHandler: function($e) {
            if ('mouse' == $e.pointerType) return;
            if ($e.srcElement.closest('.main-nav')) return;
            var wheelDirection = null,
                touchDirection = '',
                self = this;

            setTimeout(() => {
                self.updateSectionHeight();
            }, 300);
            if (
                $e.type &&
                ('touchmove' == $e.type ||
                    ($e.pointerType && $e.pointerType != 'mouse'))
            ) {
                this.touchendY = self.getEventsPage($e).y;
                if (this.touchstartY == this.touchendY) {
                    return;
                }

                if (this.touchstartY > this.touchendY) {
                    touchDirection = 'up';
                } else if (this.touchendY > this.touchstartY) {
                    touchDirection = 'down';
                }
            } else {
                wheelDirection =
                    $e.wheelDelta == undefined
                        ? $e.deltaY > 0
                        : $e.wheelDelta < 0;
            }

            let currentSection = document.querySelector(
                    '.section-wrapper.active .section-scroll'
                ),
                nextSection = self.getNextSection(
                    wheelDirection,
                    touchDirection
                ),
                nextSectionOffsetTop,
                sectionWrappers = document.querySelectorAll('.section-wrapper');

            // If is the last section, then change the offsetTop value
            if (
                wheelDirection &&
                self.getCurrentIndex() == sectionWrappers.length - 1
            ) {
                nextSectionOffsetTop = document.documentElement.scrollHeight;
            } else if (!wheelDirection && self.getCurrentIndex() == 0) {
                nextSectionOffsetTop = 0;
            } else {
                nextSectionOffsetTop = nextSection.offsetTop;
            }

            if (touchDirection) {
                if (self.checkTimer) {
                    clearTimeout(self.checkTimer);
                }
                self.checkTimer = setTimeout(function() {
                    if (
                        document
                            .querySelector(
                                '.section-wrapper.active .section-scroll'
                            )
                            .classList.contains('section-scroll-scrollable')
                    ) {
                        document
                            .querySelector('body')
                            .classList.remove('overflow-hidden'); //html
                    } else {
                        document
                            .querySelector('body')
                            .classList.add('overflow-hidden'); // html
                    }
                }, 1200);
            }

            // For non full height sections
            if (
                currentSection.classList.contains('section-scroll-scrollable')
            ) {
                if (!self.flag && !self.scrollableFlag) {
                    if (wheelDirection || touchDirection == 'up') {
                        if (
                            nextSection &&
                            window.pageYOffset + window.innerHeight >=
                                nextSectionOffsetTop
                        ) {
                            self.flag = true;
                            setTimeout(function() {
                                setTimeout(function() {
                                    self.flag = false;
                                }, 500);
                            }, 1000);

                            // Move to the next section
                            self.moveTo(nextSectionOffsetTop);
                            // Change Section Active Class
                            self.changeSectionActiveState(nextSection);

                            document.querySelector('header').style =
                                'opacity: 0; transition: ease opacity .5s;';

                            self.changeDotsActiveState();
                            setTimeout(function() {
                                document.querySelector(
                                    'header'
                                ).style.opacity = 1;
                            }, 500);

                            return;
                        }

                        if (!touchDirection) {
                            for (var i = 1; i < 100; i++) {
                                window.scrollTo(0, window.pageYOffset + 1);

                                if (
                                    window.pageYOffset + window.innerHeight >=
                                    nextSectionOffsetTop
                                ) {
                                    self.scrollableFlag = true;
                                    setTimeout(function() {
                                        self.scrollableFlag = false;
                                    }, 500);
                                    break;
                                }
                            }
                        }
                    } else {
                        if (window.pageYOffset <= currentSection.offsetTop) {
                            self.flag = true;
                            setTimeout(function() {
                                setTimeout(function() {
                                    self.flag = false;
                                }, 500);
                            }, 1000);

                            if (self.getCurrentIndex() == 0) {
                                return false;
                            }

                            // Move to the next section
                            self.moveTo(
                                currentSection.offsetTop - window.innerHeight
                            );

                            // Change Section Active Class
                            self.changeSectionActiveState(nextSection);

                            document.querySelector('header').style =
                                'opacity: 0; transition: ease opacity .5s;';

                            // Change Dots Active Class
                            self.changeDotsActiveState();

                            setTimeout(function() {
                                document.querySelector(
                                    'header'
                                ).style.opacity = 1;
                            }, 500);

                            return;
                        } else if (!touchDirection) {
                            for (var i = 1; i < 100; i++) {
                                // $('body, html').scrollTop($(window).scrollTop() - 1);
                                window.scrollTo(0, window.pageYOffset - 1); // mine

                                if (
                                    window.pageYOffset <=
                                    currentSection.offsetTop
                                ) {
                                    self.scrollableFlag = true;
                                    setTimeout(function() {
                                        self.scrollableFlag = false;
                                    }, 500);
                                    break;
                                }
                            }
                        }
                    }

                    // Change Dots Active Class
                    self.changeDotsActiveState();

                    setTimeout(function() {
                        document.querySelector('header').style.opacity = 1;
                    }, 500);
                    return;
                }
            }

            if (
                touchDirection &&
                Math.abs(self.touchstartY - self.touchendY) <=
                    (window.innerHeight / 100) * 2
            ) {
                return;
            }

            // For full height sections
            if (!self.flag && !self.scrollableFlag) {
                if (wheelDirection || touchDirection == 'up') {
                    if (self.getCurrentIndex() == sectionWrappers.length - 1) {
                        return; //return false;
                    }

                    // Change Section Active Class
                    self.changeSectionActiveState(nextSection);

                    setTimeout(function() {
                        // Move to the next section
                        self.moveTo(nextSection.offsetTop);
                    }, 150);
                } else {
                    if (self.getCurrentIndex() == 0) {
                        return; //return false;
                    }

                    // Change Section Active Class
                    self.changeSectionActiveState(nextSection);

                    if (
                        nextSection.getBoundingClientRect().height >
                        window.innerHeight
                    ) {
                        // Move to the next section
                        self.moveTo(
                            currentSection.offsetTop - window.innerHeight
                        );
                    } else {
                        setTimeout(function() {
                            // Move to the next section
                            self.moveTo(nextSection.offsetTop);
                        }, 150);
                    }
                }

                // Change Dots Active Class
                self.changeDotsActiveState();

                document.querySelector('header').style =
                    'opacity: 0; transition: ease opacity .5s;';
                nextSection.style =
                    'position:relative; opacity: 1; z-index: 1;';
                currentSection.style =
                    'position: fixed; width: 100%; top: 0;left: 0; opacity: 0; z-index: 0; transition: ease opacity .6s;';

                setTimeout(function() {
                    currentSection.style =
                        'position:relative; opacity: 1; height: 100vh';

                    document.querySelector('header').style.opacity = 1;

                    setTimeout(function() {
                        self.flag = false;
                    }, 500);
                }, 1000);

                self.flag = true;
            }
        },

        getCurrentIndex: function() {
            var currentIndex = 0;
            let sectionWrappers = document.querySelectorAll('.section-wrapper');
            for (let i = 0; i < sectionWrappers.length; i++) {
                if (sectionWrappers[i].classList.contains('active')) {
                    currentIndex = i;
                    return currentIndex;
                }
            }
            return currentIndex;
        },

        getNextSection: function(wheelDirection, touchDirection) {
            var nextSection = '',
                sectionWrappers = document.querySelectorAll('.section-wrapper');

            // Scroll Direction
            if (wheelDirection || touchDirection == 'up') {
                if (this.getCurrentIndex() == sectionWrappers.length - 1)
                    return null;
                nextSection =
                    sectionWrappers[this.getCurrentIndex() + 1].children[0];
            } else {
                if (this.getCurrentIndex() == 0) return null;
                nextSection =
                    sectionWrappers[this.getCurrentIndex() - 1].children[0];
            }

            return nextSection;
        },

        moveTo: function(to) {
            let self = this;
            if (isSafariBrowser() || isEdgeBrowser()) {
                let pos = window.pageYOffset;
                if (to < pos) {
                    let timerId1 = setInterval(() => {
                        if (pos - 100 <= to) {
                            window.clearInterval(timerId1);
                            window.scrollTo(0, to);
                            return;
                        }
                        window.scrollBy(0, -100);
                        pos -= 100;
                    }, 1);
                } else if (to >= pos) {
                    let timerId2 = setInterval(() => {
                        if (pos + 100 >= to) {
                            window.clearInterval(timerId2);
                            window.scrollTo(0, to);
                            return;
                        }
                        window.scrollBy(0, 100);
                        pos += 100;
                    }, 1);
                }
            } else {
                window.scrollTo({
                    top: to,
                    behavior: 'smooth'
                });
            }
        },

        changeSectionActiveState: function(nextSection) {
            if (!nextSection) return;
            if (document.querySelector('.section-wrapper.active')) {
                document
                    .querySelector('.section-wrapper.active')
                    .classList.remove('active');
            }

            nextSection.parentElement.classList.add('active');
        },

        changeDotsActiveState: function() {
            document
                .querySelector('.section-scroll-nav > ul > li.active')
                .classList.remove('active');
            document
                .querySelectorAll('.section-scroll-nav > ul > li')
                [this.getCurrentIndex()].classList.add('active');
        },

        dotsNavigation: function() {
            var self = this;

            let currentSectionIndex = self.getCurrentIndex();
            if (!document.querySelector('.section-scroll-nav')) {
                // let length = document.querySelectorAll('.section-scroll').length;
                let length = 6;

                let temp =
                    '<div class="section-scroll-nav"><ul class="list list-unstyled">';
                for (let i = 0; i < length; i++) {
                    temp +=
                        '<li' +
                        (currentSectionIndex == i ? ' class="active"' : '') +
                        '><a href="#' +
                        i +
                        '" data-nav-id="' +
                        i +
                        '"><span>Section-' +
                        i +
                        '</span></a></li>';
                }

                temp += '</ul></div>';
                let dotsNav = document.createElement('div');

                document.querySelector('.page-wrapper').append(dotsNav);
                dotsNav.outerHTML = temp;
            }

            let dots = document.querySelectorAll('.section-scroll-nav a');
            for (let i = 0; i < dots.length; i++) {
                dots[i].addEventListener('click', self.dotClickHandler);
                dots[i].addEventListener('touchstart', self.dotClickHandler);
            }
        },

        dotClickHandler: function($event) {
            $event.preventDefault();
            let self = this;
            let sectionScrolls = document.querySelectorAll('.section-scroll');
            let sectionWrappers = document.querySelectorAll('.section-wrapper');
            for (let i = 0; i < sectionScrolls.length; i++) {
                sectionScrolls[i].style.opacity = 0;
                sectionScrolls[i].style.transition = 'ease opacity .3s';
            }

            document.querySelector('header').style =
                'opacity: 0; transition: ease opactiy .5s';

            setTimeout(function() {
                self.moveTo(
                    sectionWrappers[$event.target.getAttribute('data-nav-id')]
                        .offsetTop
                );

                document
                    .querySelector('.section-wrapper.active')
                    .classList.remove('active');
                sectionWrappers[
                    $event.target.getAttribute('data-nav-id')
                ].classList.add('active');

                document.querySelector(
                    '.section-wrapper.active .section-scroll'
                ).style.opacity = 1;

                setTimeout(function() {
                    for (let i = 0; i < sectionScrolls.length; i++) {
                        sectionScrolls[i].style.opacity = 1;
                    }

                    document.querySelector('header').style.opacity = 1;
                }, 500);

                self.changeDotsActiveState();
            }, 500);
        },

        openVideoModal: function() {
            this.$modal.show(
                () => import('~/components/elements/modals/VideoModal'),
                {},
                { width: '1060', height: '596', adaptive: true }
            );
        }
    }
};
</script>