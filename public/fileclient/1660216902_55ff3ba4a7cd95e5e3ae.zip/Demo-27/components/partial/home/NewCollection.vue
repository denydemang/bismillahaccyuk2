<template>
	<div class="product-section section-scroll">
		<div class="swiper-carousel brands-border swiper-2">
			<div v-swiper:swiper2="carouselSetting2">
				<div class="swiper-wrapper">
					<div
						class="swiper-slide"
						v-for="(brand, index) in homeData.brands"
						:key="index"
					>
						<a
							href="javascript:;"
							class="brand"
						>
							<img
								v-lazy="brand.image"
								class="bg-transparent"
								alt="Brand"
								:width="brand.width"
								:height="brand.height"
							/>
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="heading text-center mt-6">
				<h3 class="text-secondary">Recent Arrivals</h3>
				<h6 class="font-weight-light">Find your dream living room</h6>
			</div>

			<div class="swiper-carousel carousel-with-shadow swiper-1">
				<div
					class="mb-0"
					v-swiper:swiper1="carouselSetting1"
				>
					<div class="swiper-wrapper">
						<div
							class="swiper-slide"
							v-for="(product, index) in products"
							:key="index"
						>
							<product-twelve :product="product"></product-twelve>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<script>
import ProductTwelve from '~/components/elements/products/ProductTwelve';
import { catFilter } from '~/utilities/common';
import { homeData } from '~/utilities/data';
import { carouselSettingDefault, carouselSetting1 } from '~/utilities/carousel';

export default {
	components: {
		ProductTwelve
	},
	props: {
		products: Array
	},
	data: function() {
		return {
			carouselSetting1: {
				...carouselSetting1
			},
			carouselSetting2: {
				...carouselSettingDefault,
				slidesPerView: 6,
				spaceBetween: 0,
				breakpoints: {
					992: {
						slidesPerView: 5
					},
					768: {
						slidesPerView: 4
					},
					576: {
						slidesPerView: 3
					},
					480: {
						slidesPerView: 2
					}
				}
			},
			homeData: homeData
		};
	},
	computed: {
		furniture: function() {
			return catFilter(this.products, ['furniture']);
		},
		decoration: function() {
			return catFilter(this.products, ['decoration']);
		},
		lighting: function() {
			return catFilter(this.products, ['lighting']);
		}
	}
};
</script>