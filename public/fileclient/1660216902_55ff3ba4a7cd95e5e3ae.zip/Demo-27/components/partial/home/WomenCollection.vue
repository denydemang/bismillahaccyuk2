<template>
	<div class="section section-scroll women-section">
		<figure class="banner-left">
			<nuxt-link
				to="/shop/sidebar/list"
				v-lazy:background-image="'./images/home/banners/1.jpg'"
				style="background-color: #c79369;"
			></nuxt-link>
			<div class="banner-content">
				<h5 class="banner-subtitle text-primary font-weight-normal">NEW SEASON STYLES</h5>
				<h3 class="banner-title">Women's</h3>
				<p class="banner-desc font-weight-normal">Donec odio. Quisque volutpat mattis eros. Nullam malesuada erat ut. Suspendisse urna nibh, viverra non, semper suscipite.</p>
				<nuxt-link
					to="/shop/sidebar/list"
					class="btn btn-secondary"
				>VIEW OUR COLLECTION</nuxt-link>
			</div>

		</figure>

		<div class="swiper-carousel swiper-simple">
			<div v-swiper:swiper1="carouselSetting">
				<div class="swiper-wrapper">
					<div class="swiper-slide">
						<figure class="product">
							<nuxt-link :to="'/product/default/'+ products[1].slug">
								<img
									v-lazy="`${baseUrl}${products[1].pictures[0].url}`"
									alt="Product"
									:width="products[1].pictures[0].width"
									:height="products[1].pictures[0].height"
								/>
							</nuxt-link>
							<div class="hotspot-wrapper hotspot-1">
								<nuxt-link
									:to="'/product/default/'+ products[1].slug"
									class="hotspot"
								>
									<i class="icon-plus"></i>
								</nuxt-link>
								<div class="tooltip right-tooltip">
									<figure class="product-media">
										<nuxt-link :to="'/product/default/'+ products[1].slug">
											<img
												v-lazy="`${baseUrl}${products[1].sm_pictures[0].url}`"
												alt="Product"
												:width="products[1].sm_pictures[0].width"
												:height="products[1].sm_pictures[0].height"
											/>
										</nuxt-link>
										<div class="product-body">
											<div class="product-title">{{products[1].name}}</div>
											<div class="product-price">{{products[1].price}}</div>
											<nuxt-link
												:to="'/product/default/' + products[1].slug"
												class="btn-link"
												v-if="products[1].variants.length > 0"
											>
												<span>View Products</span>
											</nuxt-link>
											<button
												class="btn-link"
												@click.prevent="addToCart( {product: products[1]} )"
												v-else
											>
												<span>Add To Cart</span>
											</button>
										</div>
									</figure>
								</div>
							</div>
							<div class="hotspot-wrapper hotspot-2">
								<nuxt-link
									:to="'/product/default/'+ products[1].slug"
									class="hotspot active"
								>
									<i class="icon-plus"></i>
								</nuxt-link>
								<div class="tooltip right-tooltip">
									<figure class="product-media">
										<nuxt-link :to="'/product/default/'+ products[1].slug">
											<img
												v-lazy="`${baseUrl}${products[1].sm_pictures[1].url}`"
												alt="Product"
												:width="products[1].sm_pictures[1].width"
												:height="products[1].sm_pictures[1].height"
											/>
										</nuxt-link>
										<div class="product-body">
											<div class="product-title">{{products[1].name}}</div>
											<div class="product-price">{{products[1].price}}</div>
											<nuxt-link
												:to="'/product/default/' + products[1].slug"
												class="btn-link"
												v-if="products[1].variants.length > 0"
											>
												<span>View Products</span>
											</nuxt-link>
											<button
												class="btn-link"
												@click.prevent="addToCart( {product: products[1]} )"
												v-else
											>
												<span>Add To Cart</span>
											</button>
										</div>
									</figure>
								</div>
							</div>
						</figure>
					</div>
					<div class="swiper-slide">
						<figure class="product">
							<nuxt-link :to="'/product/default/'+ products[2].slug">
								<img
									v-lazy="`${baseUrl}${products[2].pictures[0].url}`"
									alt="Product"
									:width="products[2].pictures[0].width"
									:height="products[2].pictures[0].height"
								/>
							</nuxt-link>
							<div class="hotspot-wrapper hotspot-3">
								<nuxt-link
									:to="'/product/default/'+ products[2].slug"
									class="hotspot"
								>
									<i class="icon-plus"></i>
								</nuxt-link>
								<div class="tooltip left-tooltip">
									<figure class="product-media">
										<nuxt-link :to="'/product/default/'+ products[2].slug">
											<img
												v-lazy="`${baseUrl}${products[2].sm_pictures[0].url}`"
												alt="Product"
												:width="products[2].sm_pictures[0].width"
												:height="products[2].sm_pictures[0].height"
											/>
										</nuxt-link>
										<div class="product-body">
											<div class="product-title">{{products[2].name}}</div>
											<div class="product-price">{{products[2].price}}</div>
											<nuxt-link
												:to="'/product/default/' + products[2].slug"
												class="btn-link"
												v-if="products[2].variants.length > 0"
											>
												<span>View Products</span>
											</nuxt-link>
											<button
												class="btn-link"
												@click.prevent="addToCart( {product: products[2]} )"
												v-else
											>
												<span>Add To Cart</span>
											</button>
										</div>
									</figure>
								</div>
							</div>
						</figure>
					</div>
					<div class="swiper-slide">
						<figure class="product">
							<nuxt-link :to="'/product/default/'+ products[3].slug">
								<img
									v-lazy="`${baseUrl}${products[3].pictures[0].url}`"
									alt="Product"
									:width="products[3].pictures[0].width"
									:height="products[3].pictures[0].height"
								/>
							</nuxt-link>
							<div class="hotspot-wrapper hotspot-4">
								<nuxt-link
									:to="'/product/default/'+ products[3].slug"
									class="hotspot"
								>
									<i class="icon-plus"></i>
								</nuxt-link>
								<div class="tooltip right-tooltip">
									<figure class="product-media">
										<nuxt-link :to="'/product/default/'+ products[3].slug">
											<img
												v-lazy="`${baseUrl}${products[3].sm_pictures[0].url}`"
												alt="Product"
												:width="products[3].sm_pictures[0].width"
												:height="products[3].sm_pictures[0].height"
											/>
										</nuxt-link>
										<div class="product-body">
											<div class="product-title">{{products[3].name}}</div>
											<div class="product-price">{{products[3].price}}</div>
											<nuxt-link
												:to="'/product/default/' + products[3].slug"
												class="btn-link"
												v-if="products[3].variants.length > 0"
											>
												<span>View Products</span>
											</nuxt-link>
											<button
												class="btn-link"
												@click.prevent="addToCart( {product: products[3]} )"
												v-else
											>
												<span>Add To Cart</span>
											</button>
										</div>
									</figure>
								</div>
							</div>
							<div class="hotspot-wrapper hotspot-5">
								<nuxt-link
									:to="'/product/default/'+ products[3].slug"
									class="hotspot active"
								>
									<i class="icon-plus"></i>
								</nuxt-link>
								<div class="tooltip right-tooltip">
									<figure class="product-media">
										<nuxt-link :to="'/product/default/'+ products[3].slug">
											<img
												v-lazy="`${baseUrl}${products[3].sm_pictures[0].url}`"
												alt="Product"
												:width="products[3].sm_pictures[0].width"
												:height="products[3].sm_pictures[0].height"
											/>
										</nuxt-link>
										<div class="product-body">
											<div class="product-title">{{products[3].name}}</div>
											<div class="product-price">{{products[3].price}}</div>
											<nuxt-link
												:to="'/product/default/' + products[3].slug"
												class="btn-link"
												v-if="products[3].variants.length > 0"
											>
												<span>View Products</span>
											</nuxt-link>
											<button
												class="btn-link"
												@click.prevent="addToCart( {product: products[3]} )"
												v-else
											>
												<span>Add To Cart</span>
											</button>
										</div>
									</figure>
								</div>
							</div>
						</figure>
					</div>
				</div>
			</div>
			<div class="swiper-nav nav-rounded">
				<div class="swiper-prev">
					<i class="icon-angle-left"></i>
				</div>
				<div class="swiper-next">
					<i class="icon-angle-right"></i>
				</div>
			</div>
		</div>
	</div>
</template>
<script>
import { mapGetters, mapActions } from 'vuex';
import { baseUrl } from '~/repositories/repository.js';
import { carouselSettingDefault } from '~/utilities/carousel';
export default {
	props: {
		products: Array
	},
	data: function() {
		return {
			carouselSetting: {
				...carouselSettingDefault,
				slidesPerView: 1.65,
				breakpoints: {
					992: {
						slidesPerView: 1.65
					},
					768: {
						slidesPerView: 2
					},
					576: {
						slidesPerView: 2
					},
					480: {
						slidesPerView: 1
					}
				},
				navigation: {
					nextEl: '.women-section .swiper-next',
					prevEl: '.women-section .swiper-prev'
				}
			},
			baseUrl: baseUrl
		};
	},
	computed: {
		...mapGetters('cart', ['canAddToCart'])
	},
	methods: {
		...mapActions('cart', ['addToCart'])
	}
};
</script>