<template>
	<div class="section section-scroll men-section">
		<figure class="banner-right">
			<div class="banner-content">
				<h5 class="banner-subtitle text-primary font-weight-normal">NEW SEASON STYLES</h5>
				<h3 class="banner-title">Men's</h3>
				<p class="banner-desc font-weight-normal">Quisque volutpat mattis eros. Nullam malesuada erat ut turpis. Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede.</p>
				<nuxt-link
					to="/shop/sidebar/2cols"
					class="btn btn-secondary"
				>VIEW OUR COLLECTION</nuxt-link>
			</div>
			<nuxt-link
				to="/shop/sidebar/2cols"
				v-lazy:background-image="'./images/home/banners/3.jpg'"
				style="background-color: #c79369;"
			></nuxt-link>

		</figure>

		<div class="swiper-carousel swiper-simple">
			<div
				v-swiper:swiper1="carouselSetting"
				style="margin-right: -10px;"
			>
				<div
					class="swiper-wrapper"
					style="padding-right: 10px;"
				>
					<div class="swiper-slide">
						<figure class="product">
							<nuxt-link :to="'/product/default/'+ products[3].slug">
								<img
									v-lazy="`${baseUrl}${products[3].pictures[0].url}`"
									alt="Product"
									:width="products[3].pictures[0].width"
									:height="products[3].pictures[0].height"
								/>
							</nuxt-link>
							<div class="hotspot-wrapper hotspot-2">
								<nuxt-link
									:to="'/product/default/'+ products[3].slug"
									class="hotspot"
								>
									<i class="icon-plus"></i>
								</nuxt-link>
								<div class="tooltip right-tooltip">
									<figure class="product-media">
										<nuxt-link :to="'/product/default/'+ products[3].slug">
											<img
												v-lazy="`${baseUrl}${products[3].sm_pictures[0].url}`"
												alt="Product"
												:width="products[3].sm_pictures[0].width"
												:height="products[3].sm_pictures[0].height"
											/>
										</nuxt-link>
										<div class="product-body">
											<div class="product-title">{{products[3].name}}</div>
											<div class="product-price">{{products[3].price}}</div>
											<nuxt-link
												:to="'/product/default/' + product.slug"
												class="btn-link"
												v-if="products[3].variants.length > 0"
											>
												<span>View Products</span>
											</nuxt-link>
											<button
												class="btn-link"
												@click.prevent="addToCart( {product: products[3]} )"
												v-else
											>
												<span>Add To Cart</span>
											</button>
										</div>
									</figure>
								</div>
							</div>
						</figure>
					</div>
					<div class="swiper-slide">
						<figure class="product">
							<nuxt-link :to="'/product/default/'+ products[4].slug">
								<img
									v-lazy="`${baseUrl}${products[4].pictures[0].url}`"
									alt="Product"
									:width="products[4].pictures[0].width"
									:height="products[4].pictures[0].height"
								/>
							</nuxt-link>
							<div class="hotspot-wrapper hotspot-1">
								<nuxt-link
									:to="'/product/default/'+ products[4].slug"
									class="hotspot"
								>
									<i class="icon-plus"></i>
								</nuxt-link>
								<div class="tooltip left-tooltip">
									<figure class="product-media">
										<nuxt-link :to="'/product/default/'+ products[4].slug">
											<img
												v-lazy="`${baseUrl}${products[4].sm_pictures[0].url}`"
												alt="Product"
												:width="products[4].sm_pictures[0].width"
												:height="products[4].sm_pictures[0].height"
											/>
										</nuxt-link>
										<div class="product-body">
											<div class="product-title">{{products[4].name}}</div>
											<div class="product-price">{{products[4].price}}</div>
											<nuxt-link
												:to="'/product/default/' + product.slug"
												class="btn-link"
												v-if="products[4].variants.length > 0"
											>
												<span>View Products</span>
											</nuxt-link>
											<button
												class="btn-link"
												@click.prevent="addToCart( {product: products[4]} )"
												v-else
											>
												<span>Add To Cart</span>
											</button>
										</div>
									</figure>
								</div>
							</div>
						</figure>
					</div>
					<div class="swiper-slide">
						<figure class="product">
							<nuxt-link :to="'/product/default/'+ products[5].slug">
								<img
									v-lazy="`${baseUrl}${products[5].pictures[0].url}`"
									alt="Product"
									:width="products[5].pictures[0].width"
									:height="products[5].pictures[0].height"
								/>
							</nuxt-link>
							<div class="hotspot-wrapper hotspot-4">
								<nuxt-link
									:to="'/product/default/'+ products[5].slug"
									class="hotspot"
								>
									<i class="icon-plus"></i>
								</nuxt-link>
								<div class="tooltip right-tooltip">
									<figure class="product-media">
										<nuxt-link :to="'/product/default/'+ products[5].slug">
											<img
												v-lazy="`${baseUrl}${products[5].sm_pictures[0].url}`"
												alt="Product"
												:width="products[5].sm_pictures[0].width"
												:height="products[5].sm_pictures[0].height"
											/>
										</nuxt-link>
										<div class="product-body">
											<div class="product-title">{{products[5].name}}</div>
											<div class="product-price">{{products[5].price}}</div>
											<nuxt-link
												:to="'/product/default/' + product.slug"
												class="btn-link"
												v-if="products[5].variants.length > 0"
											>
												<span>View Products</span>
											</nuxt-link>
											<button
												class="btn-link"
												@click.prevent="addToCart( {product: products[5]} )"
												v-else
											>
												<span>Add To Cart</span>
											</button>
										</div>
									</figure>
								</div>
							</div>
						</figure>
					</div>
				</div>
			</div>
			<div class="swiper-nav nav-rounded">
				<div class="swiper-prev">
					<i class="icon-angle-left"></i>
				</div>
				<div class="swiper-next">
					<i class="icon-angle-right"></i>
				</div>
			</div>
		</div>
	</div>
</template>
<script>
import { mapGetters, mapActions } from 'vuex';
import { baseUrl } from '~/repositories/repository.js';
import { carouselSettingDefault } from '~/utilities/carousel';
export default {
	props: {
		products: Array
	},
	data: function() {
		return {
			carouselSetting: {
				...carouselSettingDefault,
				slidesPerView: 2,
				breakpoints: {
					768: {
						slidesPerView: 2
					},
					576: {
						slidesPerView: 2
					},
					480: {
						slidesPerView: 1
					}
				},
				navigation: {
					nextEl: '.men-section .swiper-next',
					prevEl: '.men-section .swiper-prev'
				}
			},
			baseUrl: baseUrl
		};
	},
	computed: {
		...mapGetters('cart', ['canAddToCart'])
	},
	methods: {
		...mapActions('cart', ['addToCart'])
	}
};
</script>