<template>
	<div class="section-wrapper">
		<footer class="footer section-scroll">
			<div class="container">
				<div class="footer-top">
					<div class="newsletter justify-content-center pt-8 pb-5">
						<div class="newsletter-heading text-center">
							<h3 class="newsletter-title text-white">Get The Latest Deals</h3>
							<p class="newsletter-desc">and receive $20 coupon for first shopping</p>
						</div>

						<form action="#">
							<div class="input-group">
								<input
									type="email"
									class="form-control"
									placeholder="Enter your Email Address"
									aria-label="Email Adress"
									required
								>
								<div class="input-group-append">
									<button
										class="btn btn-white"
										type="submit"
										title="Sing up"
									>SUBSCRIBE</button>
								</div>
							</div>
						</form>
					</div>
				</div>

				<hr class="spacing mt-5">

				<div class="footer-main">
					<div class="swiper-carousel swiper-theme swiper-icon-box mt-2 mb-2">
						<div v-swiper:swiper1="carouselSetting">
							<div class="swiper-wrapper">
								<div class="swiper-slide">
									<div class="icon-box icon-box-side">
										<span class="icon-box-icon">
											<i class="icon-truck"></i>
										</span>
										<div class="icon-box-content">
											<h3 class="icon-box-title text-white font-weight-normal">PAYMENT & DELIVERY</h3>
											<p>Free shipping for orders over $50</p>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="icon-box icon-box-side">
										<span class="icon-box-icon">
											<i class="icon-rotate-left"></i>
										</span>

										<div class="icon-box-content">
											<h3 class="icon-box-title text-white font-weight-normal">RETURN & REFUND</h3>
											<p>Free 100% money back guarantee</p>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="icon-box icon-box-side">
										<span class="icon-box-icon">
											<i class="icon-life-ring"></i>
										</span>

										<div class="icon-box-content">
											<h3 class="icon-box-title text-white font-weight-normal">QUALITY SUPPORT</h3>
											<p>Alway online feedback 24/7</p>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="icon-box icon-box-side">
										<span class="icon-box-icon">
											<i class="icon-envelope"></i>
										</span>

										<div class="icon-box-content">
											<h3 class="icon-box-title text-white font-weight-normal">JOIN OUR NEWSLETTER</h3>
											<p>10% off by subscribing to our newsletter</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

					<hr class="spacing mb-5">

					<div class="row widget">
						<div class="col-xl-2-5col">
							<div class="widget widget-about">
								<img
									src="~/static/images/home/footer-logo.png"
									class="footer-logo bg-transparent"
									alt="Footer Logo"
									width="82"
									height="20"
								>
								<p>Praesent dapibus, neque id cursus ucibus, tortor neque egestas augue, eu vulputate magna eros eu erat. Aliquam erat volutpat. Nam dui mi, tincidunt quis, accumsan porttitor, facilisis luctus, metus. </p>

								<div class="widget-about-info">
									<div class="phone-num">
										<span class="widget-about-title">Got Question? Call us 24/7</span>
										<a
											href="tel:123456789"
											class="text-white"
										>+0123 456 789</a>
									</div>

									<div class="payments">
										<span class="widget-about-title">Payment Method</span>
										<figure class="footer-payments">
											<img
												src="~/static/images/payments.png"
												class="bg-transparent"
												alt="Payment methods"
												width="272"
												height="20"
											>
										</figure>
									</div>
								</div>
							</div>
						</div>

						<div class="col-sm-4 col-xl-5col">
							<div class="widget">
								<h4 class="widget-title text-white font-weight-normal mb-2">INFORMATION</h4>

								<ul class="widget-list">
									<li>
										<nuxt-link to="/pages/about">About Molla</nuxt-link>
									</li>
									<li>
										<a href="#">How to shop on Molla</a>
									</li>
									<li>
										<a href="#">FAQ</a>
									</li>
									<li>
										<nuxt-link to="/pages/contact">Contact us</nuxt-link>
									</li>
									<li>
										<nuxt-link to="/pages/login">Log in</nuxt-link>
									</li>
								</ul>
							</div>
						</div>

						<div class="col-sm-4 col-xl-5col">
							<div class="widget">
								<h4 class="widget-title text-white font-weight-normal mb-2">CUSTOMER SERVICE</h4>

								<ul class="widget-list">
									<li><a href="#">Payment Methods</a></li>
									<li><a href="#">Money-back guarantee!</a></li>
									<li><a href="#">Returns</a></li>
									<li><a href="#">Shipping</a></li>
									<li><a href="#">Terms and conditions</a></li>
									<li><a href="#">Privacy Policy</a></li>
								</ul>
							</div>
						</div>

						<div class="col-sm-4 col-xl-5col">
							<div class="widget">
								<h4 class="widget-title text-white font-weight-normal mb-2">MY ACCOUNT</h4>

								<ul class="widget-list">
									<li>
										<a href="#">Sign In</a>
									</li>
									<li>
										<nuxt-link to="/shop/cart">View Cart</nuxt-link>
									</li>
									<li>
										<nuxt-link to="/shop/wishlist">My Wishlist</nuxt-link>
									</li>
									<li>
										<nuxt-link to="/shop/dashboard">Track My Order</nuxt-link>
									</li>
									<li>
										<a href="#">Help</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>

				<div class="footer-bottom">
					<div class="container">
						<p class="footer-copyright">Copyright © {{ new Date().getFullYear() }} Molla Store. All Rights Reserved.</p>
						<ul class="footer-menu">
							<li><a href="#">Terms Of Use</a></li>
							<li><a href="#">Privacy Policy</a></li>
						</ul>

						<div class="social-icons social-icons-color">
							<span class="social-label">Social Media</span>
							<a
								href="#"
								class="social-icon social-facebook"
								title="Facebook"
								target="_blank"
							><i class="icon-facebook-f"></i></a>
							<a
								href="#"
								class="social-icon social-twitter"
								title="Twitter"
								target="_blank"
							><i class="icon-twitter"></i></a>
							<a
								href="#"
								class="social-icon social-instagram"
								title="Instagram"
								target="_blank"
							><i class="icon-instagram"></i></a>
							<a
								href="#"
								class="social-icon social-youtube"
								title="Youtube"
								target="_blank"
							><i class="icon-youtube"></i></a>
							<a
								href="#"
								class="social-icon social-pinterest"
								title="Pinterest"
								target="_blank"
							><i class="icon-pinterest"></i></a>
						</div>
					</div>
				</div>

			</div>
		</footer>
	</div>
</template>

<script>
import { carouselSetting1 } from '~/utilities/carousel';
export default {
	data: function() {
		return {
			bottomSticky: false,
			carouselSetting: {
				...carouselSetting1,
				breakpoints: {
					768: {
						slidesPerView: 2
					},
					576: {
						slidesPerView: 1
					}
				},
				slidesPerView: 4,
				spaceBetween: 20
			}
		};
	},
	computed: {
		isFullwidth: function() {
			return this.$route.path.includes('fullwidth');
		}
	},
	watch: {
		$route: function() {
			this.handleBottomSticky();
		}
	},
	mounted: function() {
		this.handleBottomSticky();
		window.addEventListener('resize', this.handleBottomSticky, {
			passive: true
		});
	},
	destroyed: function() {
		window.removeEventListener('resize', this.handleBottomSticky);
	},
	methods: {
		handleBottomSticky: function() {
			this.bottomSticky =
				this.$route.path.includes('/product/default') &&
				window.innerWidth > 991;
		}
	}
};
</script>