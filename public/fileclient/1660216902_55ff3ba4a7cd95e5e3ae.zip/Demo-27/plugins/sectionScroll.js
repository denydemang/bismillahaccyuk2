import Vue from 'vue'
import VueFullPage from 'vue-fullpage.js'

Vue.use( VueFullPage );