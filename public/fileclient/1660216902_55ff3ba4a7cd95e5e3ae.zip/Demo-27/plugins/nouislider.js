import Vue from 'vue';
import VueNouislider from 'vue-nouislider/dist/vue-nouislider.common';
import 'vue-nouislider/dist/vue-nouislider.css';

Vue.use( VueNouislider );