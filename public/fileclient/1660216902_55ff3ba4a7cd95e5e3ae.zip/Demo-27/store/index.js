export const actions = {
    async nuxtServerInit ( { commit, dispatch } ) {
    }
}