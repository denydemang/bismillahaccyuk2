<template lang="html">
    <div>
        <div class="page-wrapper">
			<header-default></header-default>
			<nuxt></nuxt>
			<footer-default></footer-default>
			<button id="scroll-top" ref="scrollTop" title="Back to Top" @click.prevent="scrollTop">
				<i class="icon-arrow-up"></i>
			</button>
        </div>
        <div class="mobile-menu-overlay" @click="hideMobileMenu"></div>
        <mobile-menu></mobile-menu>
    </div>
</template>

<script>
import HeaderDefault from '~/components/partial/headers/HeaderDefault';
import FooterDefault from '~/components/partial/footers/FooterDefault';
import { isSafariBrowser, isEdgeBrowser } from '~/utilities/common';

export default {
	components: {
		HeaderDefault,
		FooterDefault,
		MobileMenu: () => import('~/components/partial/home/MobileMenu')
	},
	methods: {
		hideMobileMenu: function() {
			document.querySelector('body').classList.remove('mmenu-active');
		}
	}
};
</script>